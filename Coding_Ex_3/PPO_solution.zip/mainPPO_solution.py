from keras.models import Sequential
from keras.layers import Dense
import tensorflow as tf
import gym
import numpy as np
import scipy.signal
import matplotlib.pyplot as plt

class GymEnvironment:
    def __init__(self, env_id, monitor_dir, max_timesteps=10000):

        self.max_timesteps = max_timesteps # Define maximum number of timesteps the agent can balance the pole
        self.env = gym.make(env_id) # Create the environment

    def trainPPO(self, agent, no_episodes):

        rew,total_episodes = self.runPPO(agent, no_episodes,training = True)

        return rew,total_episodes

    def runPPO(self, agent, no_episodes,training = False):

        rew = np.zeros((agent.actors,no_episodes))
        episode = 0

        # Main loop, see PPO pseudo-code in lecture
        for episode in range(no_episodes):
            agent.initialize_buffers()
            for n in range(0,agent.actors):
                tot_rew = 0
                state = self.env.reset()[0] # Reset environment for each actor
                for t in range(self.max_timesteps):

                    encoded_state = tf.convert_to_tensor([state.tolist()])
                    logit,action = agent.select_action(encoded_state) # Sample action and get the output of the NN

                    # Get new transition
                    next_state, reward, done, _,__ = self.env.step(action[0].numpy())
                    next_state = next_state.reshape(1, self.env.observation_space.shape[0])

                    if training:
                        value_t = agent.critic(encoded_state) # Get value of current state
                        logprobability_t = logprobabilities(logit, action) # Transform output of NN into log-probability for numerical stability
                        agent.record(state, action, reward, value_t,logprobability_t,n,t) # Record transition for usage in weight update

                    tot_rew += reward
                    state = next_state[0].copy()

                    # Finish trajectory if reached to a terminal state
                    if done:
                        if training:
                            agent.calc_advantage(n,t) # Calculate advantages
                        break
                rew[n,episode] = tot_rew

            if training:

                # Prepare data to be used in weight update
                reward_buffer,states_buffer,actions_buffer,logprobas_buffer,advantages_buffer,return_buffer = agent.prepare_training_data()

                # Calculate weight updates for value and policy network
                for _ in range(agent.train_policy_epochs):
                    agent.train_policy(states_buffer,actions_buffer,logprobas_buffer,advantages_buffer)
                for _ in range(agent.train_value_function_epochs):
                    agent.train_value_function(states_buffer,return_buffer)

                if episode > 1:
                    tot_rew_avg = np.average(rew[:,episode-2:episode+1]) # take average over 3 most recent episodes and all actors
                    if tot_rew_avg > 400:
                        print("episode: {}/{} | score: {}".format(
                            episode + 1, no_episodes, np.average(rew[:, episode])))
                        print('Converged after ', episode + 1, ' episodes with mean total reward of ', tot_rew_avg)
                        break
            tot_rew_avg = np.average(rew[:, episode])
            print("episode: {}/{} | score: {}".format(
                episode + 1, no_episodes, tot_rew_avg))
        return rew[:,:episode+1],episode



# Compute the log-probabilities of taking actions a by using the outputs of actor NN, mainly done for numerical stability purposes
def logprobabilities(logit, a):
        logprobabilities_all = tf.nn.log_softmax(logit)
        logprobability = tf.reduce_sum(
            tf.one_hot(a, 2) * logprobabilities_all, axis=1
        )
        return logprobability

# Discounted cumulative sums of vectors for computing sum of discounted rewards and advantage estimates
def discounted_cumulative_sums(x, discount):
    return scipy.signal.lfilter([1], [1, float(-discount)], x[::-1], axis=0)[::-1]

class PPO_Agent:
    def __init__(self, no_of_states, no_of_actions):
        self.state_size = no_of_states
        self.action_size = no_of_actions

        # Hyperparameters
        self.gamma = 0.99  # discount rate
        self.lam = 0.9 # TD(lambda) weight
        self.clip_ratio = 0.2 # Clipping ratio based on initial PPO paper

        self.actors = 4 # No. of parallel actors
        self.max_time_steps = 10000  # Maximum time steps

        self.actor = self.nn_model(no_of_states, no_of_actions) # Create actor network
        self.train_policy_epochs = 40 # Define number of epochs for multiple weight update iterations within one episode
        self.critic = self.nn_model(no_of_states, 1) # Create critic network
        self.train_value_function_epochs = 40 # Define number of epochs for multiple weight update iterations within one episode

        policy_learning_rate = 0.0003
        value_function_learning_rate = 0.001
        self.policy_optimizer = tf.keras.optimizers.Adam(learning_rate=policy_learning_rate)
        self.value_optimizer = tf.keras.optimizers.Adam(learning_rate=value_function_learning_rate)

    def initialize_buffers(self): # Initialize arrays for usage in weight updates
        self.advantages = np.zeros((self.actors,self.max_time_steps),dtype=np.float32)
        self.state_buffer = np.zeros((self.actors,self.max_time_steps,self.state_size),dtype=np.float32)
        self.action_buffer = np.zeros((self.actors,self.max_time_steps),dtype=np.int32)
        self.reward_buffer = np.zeros((self.actors,self.max_time_steps),dtype=np.float32)
        self.value_buffer = np.zeros((self.actors,self.max_time_steps),dtype=np.float32)
        self.logprobability_buffer = np.zeros((self.actors,self.max_time_steps),dtype=np.float32)
        self.return_buffer = np.zeros((self.actors,self.max_time_steps),dtype=np.float32)

    # Sample action based on policy
    @tf.function
    def select_action(self,state):
        logit = self.actor(state)
        action = tf.squeeze(tf.random.categorical(logit, 1), axis=1)
        return logit, action

    # Calculate advantages based on lambda-return for policy update and sum of discounted rewards for value updates
    def calc_advantage(self,n,T):
        # δ = r(s_t,a_t)+γV(s_{t+1})-V(s_t)
        deltas = self.reward_buffer[n,:-1] + self.gamma * self.value_buffer[n,1:] - self.value_buffer[n,:-1]

        # A(s_t,a_t) = Q(s_t,a_t)-V(s_t) = 𝔼[r(s_t,a_t)+γV(s_{t+1})|s_t,a] - V(s_t) ~ G^λ_t(s_t,a_t)-V̂(s_t) = Sum_{k=t}^{T} (γλ)^{k-t} δ_k
        # First two equalities from lecture on policy gradients and advanced policy gradients / last equality from exercise 5 in TD(λ) exercise sheet
        self.advantages[n,:-1] = discounted_cumulative_sums(deltas, self.gamma * self.lam)

        # Calculate total return (i.e., sum of discounted rewards) as target for value function update
        self.return_buffer[n,:T+1] = discounted_cumulative_sums(self.reward_buffer[n,:T+1], self.gamma)

    # Store newly observed transitions in buffer, for each actor and time step
    def record(self, state, action, reward, value, logprobability,n,t):
        self.state_buffer[n,t,:] = state
        self.action_buffer[n,t] = action
        self.reward_buffer[n,t] = reward
        self.value_buffer[n,t] = value
        self.logprobability_buffer[n,t] = logprobability

    # Store newly observed transitions in buffer
    def prepare_training_data(self):
        tmp = np.reshape(self.reward_buffer,self.max_time_steps*self.actors)
        ids = np.where(tmp>0) # Make sure to not take into account 0 rewards from time steps that were not visited as episode ended already
        reward_buffer = tmp[ids]
        tmp = np.reshape(self.state_buffer,(self.max_time_steps*self.actors,self.state_size))
        states_buffer = tmp[ids]
        tmp = np.reshape(self.action_buffer,self.max_time_steps*self.actors)
        actions_buffer = tmp[ids]
        tmp = np.reshape(self.logprobability_buffer,self.max_time_steps*self.actors)
        logprobas_buffer = tmp[ids]
        tmp = np.reshape(self.advantages,self.max_time_steps*self.actors)
        advantages_buffer = tmp[ids]
        tmp = np.reshape(self.return_buffer,self.max_time_steps*self.actors)
        return_buffer = tmp[ids]

        return reward_buffer,states_buffer,actions_buffer,logprobas_buffer,advantages_buffer,return_buffer

    # Define neural network
    def nn_model(self,state_size,output_size):
        observation_input = tf.keras.Input(shape=(state_size,), dtype=tf.float32)
        dense1 = tf.keras.layers.Dense(units=64, activation=tf.tanh)(observation_input)
        dense2 = tf.keras.layers.Dense(units=64, activation=tf.tanh)(dense1)
        output = tf.keras.layers.Dense(units=output_size,activation = None)(dense2)
        if output_size == 1:
            output = tf.squeeze(output, axis=1)
        return tf.keras.Model(inputs=observation_input, outputs=output)

    # Policy network's weight update
    @tf.function
    def train_policy(self, states, actions, logprobas, advantages):

        # Setup of policy loss function
        with tf.GradientTape() as tape:
            ratio = tf.exp(logprobabilities(self.actor(states), actions) - logprobas)  # Calculate pi_new/pi_old
            clip_advantage = tf.where(advantages > 0, (1 + self.clip_ratio) * advantages,
                                     (1 - self.clip_ratio) * advantages, )  # Apply clipping
            policy_loss = -tf.reduce_mean(tf.minimum(ratio * advantages, clip_advantage))  # Setup loss function as mean of individual L_clip and negative sign, as tf minimizes by default

        # Use gradient based optimizer to optimize loss function and update weights
        policy_grads = tape.gradient(policy_loss, self.actor.trainable_variables)
        self.policy_optimizer.apply_gradients(zip(policy_grads, self.actor.trainable_variables))

    # Update value network's weights
    @tf.function
    def train_value_function(self, states, returns):
        # Setup value network's loss function
        with tf.GradientTape() as tape:
            value_loss = tf.reduce_mean(
                (returns - self.critic(states)) ** 2)  # Train the value function by regression on mean-squared error

        # Use gradient based optimizer to optimize loss function and update weights
        value_grads = tape.gradient(value_loss, self.critic.trainable_variables)
        self.value_optimizer.apply_gradients(zip(value_grads, self.critic.trainable_variables))


if __name__ == "__main__":
    environment = GymEnvironment('CartPole-v1', 'gymresults/cartpole-v1')

    no_of_states = 4
    no_of_actions = 2


    # The agent is initialized
    agent = PPO_Agent(no_of_states,no_of_actions)


    # Train your agent
    no_episodes = 1000
    rew,total_episodes = environment.trainPPO(agent, no_episodes)

    # Run your agent
    no_episodes = 10
    agent.actors = 1
    rew,total_episodes = environment.runPPO(agent, no_episodes)
    print('Mean test reward: ', np.mean(rew))

    # Here you can watch a simulation on how your agent performs after being trained.
    visualize_agent = False
    if visualize_agent == True:
        print(f'cartpole rendering started. You can terminate it by going to your terminal and pressing CTRL+C (Windows/Mac/Linux)')
        env = gym.make('CartPole-v1', render_mode="human")
        state_size = 4
        action_size = 2
        for _ in range(20):
            state = env.reset()[0]
            done = False
            while not done:
                encoded_state = tf.convert_to_tensor([state.tolist()])
                _, action = agent.select_action(encoded_state)
                next_state, reward, done, _,__ = env.step(action[0].numpy())
                next_state = next_state.reshape(1, env.observation_space.shape[0])
                state = next_state[0].copy()
        env.close()

